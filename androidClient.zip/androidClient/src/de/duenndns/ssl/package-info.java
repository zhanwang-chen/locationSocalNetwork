/**
 * This package contains the MemorizingTrustManager library made by Georg.
 * It is a "plugin" for Android Java to allow asking the user about SSL certificates
 * https://github.com/ge0rg/MemorizingTrustManager
 */
package de.duenndns.ssl;

