package com.beem.project.beem.LocationService;

import org.jivesoftware.smack.packet.Message;

import com.beem.project.beem.R;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

public class BroadcastAroudMeActivity extends Activity{
	  private Button btnBroMs;
	  private EditText etMstoSend;
	  private TextView tvBroRes;
	  private RadioButton rdDistance1 ;
	  private RadioButton rdDistance2 ;
	  private RadioButton rdDistance3 ;
	  @Override
	    protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.broadcastaroud);
		btnBroMs = (Button) findViewById(R.id.btnBroMs); 
		etMstoSend = (EditText) findViewById(R.id.etMstoSend); 
		tvBroRes = (TextView) findViewById(R.id.tvBroRes); 
		rdDistance1 = (RadioButton) findViewById(R.id.rBtnds1); 
		rdDistance2 = (RadioButton) findViewById(R.id.rBtnds2); 
		rdDistance3 = (RadioButton) findViewById(R.id.rBtnds3);
		
		tvBroRes.setVisibility(0);
		
		
		
		btnBroMs.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				Message mes = new Message();
				mes.setBody(etMstoSend.getText().toString());
				RadioButton RBtn[] = {rdDistance1,rdDistance2,rdDistance3};
				int distance = 5000;
				for(int i = 0;i<RBtn.length;i++){
					if(RBtn[i]==null){
						break;
					}	
					if(RBtn[i].isChecked()){
						switch (i){
						    case 0:distance = 500;break;
						    case 1:distance = 1000;break;
						    case 2:distance = 2000;break;
						}
						  break;
					}
				}
				mes.setProperty("distanceToBrocast",distance);
				ServerContractor.sendmes(mes);
				etMstoSend.setText("");
				tvBroRes.setVisibility(1);
			}
			
		});
	  }
}
