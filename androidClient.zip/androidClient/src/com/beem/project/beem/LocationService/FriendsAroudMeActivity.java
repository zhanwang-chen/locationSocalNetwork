package com.beem.project.beem.LocationService;

import android.app.Activity;

public class FriendsAroudMeActivity extends Activity {

}
