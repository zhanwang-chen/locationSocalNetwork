package com.beem.project.beem.LocationService;

import com.beem.project.beem.service.XmppConnectionAdapter;
import com.beem.project.beem.service.XmppFacade;

public class XMppfacadeshare {
	
	public static	XmppConnectionAdapter xmppConnection;

     public static XmppFacade xmppfacade;

}
