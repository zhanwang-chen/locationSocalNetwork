package com.beem.project.beem.LocationService;

import java.util.List;
import java.util.Locale;

import org.jivesoftware.smack.util.StringUtils;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.RemoteException;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.TextView;
import android.widget.Toast;

import com.beem.project.beem.R;
import com.beem.project.beem.service.Contact;
import com.beem.project.beem.service.Message;
import com.beem.project.beem.service.aidl.IChat;
import com.beem.project.beem.service.aidl.IChatManager;
import com.beem.project.beem.service.aidl.IMessageListener;
import com.beem.project.beem.service.aidl.IXmppFacade;
import com.beem.project.beem.ui.ChangeStatus;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapActivity;
import com.google.android.maps.MapController;
import com.google.android.maps.MapView;
import com.google.android.maps.Overlay;

/**
 * Description: <br/>
 * site: <a href="http://www.crazyit.org">crazyit.org</a> <br/>
 * Copyright (C), 2001-2012, Yeeku.H.Lee <br/>
 * This program is protected by copyright laws. <br/>
 * Program Name: <br/>
 * Date:
 * 
 * @author Yeeku.H.Lee kongyeeku@163.com
 * @version 1.0
 */

// ����̳�MapActivity

public class LocationMap extends MapActivity {
	// ��������ϵĵĿ��ӻ��ؼ�
	private Button locBn;
	private RadioGroup mapType;
	private MapView mv;
	private TextView tvLng, tvLat;
	// ����MapController����
	private MapController controller;
	private Bitmap posBitmap;
	private Bitmap fdposBitmap;
	private ServerContractor seninfotoServer;
	private LocationManager locationManager = null;
	private boolean gpsEnabled;
	private double dLong;
	private double dLat;
	private PosOverLay selfPoint;
	private PosOverLay friendPoint;

	public Handler draPointHandler = new Handler() {
		public void handleMessage(android.os.Message msg) {
			switch (msg.what) {
			case 1:
				// button.setText(R.string.text2);
				double lon = msg.getData().getDouble("lon");
				double lat = msg.getData().getDouble("lat");
				String fName = msg.getData().getString("fName");
				addMorepoitn(lon, lat," ���� "+fName);
				break;
			default:
				break;
			}
			super.handleMessage(msg);
		}
	};
	Thread thread1 = new Thread(new Runnable() {
		@Override
		public void run() {
			Log.i("mesporcessor", "mesporcessor is running");
			while (true) {
				if (seninfotoServer != null?null!=seninfotoServer.getMesrecived():false) {
					if (seninfotoServer.getMesrecived().contains(",")&seninfotoServer.getMesrecived().contains("lonAndLat")) {
						System.out.println("recived lng and lat:"
								+ seninfotoServer.getMesrecived());
						android.os.Message message = new android.os.Message();
						Bundle bundle =new Bundle();
						
					    double lon = Double.parseDouble(seninfotoServer.getMesrecived().split(",")[0]);
					    double lat = Double.parseDouble(seninfotoServer.getMesrecived().split(",")[1]);
					    String fName = seninfotoServer.getMesrecived().split(",")[3];
					    
						bundle.putDouble("lon", lon);
						bundle.putDouble("lat", lat);
						bundle.putString("fName", fName);
						seninfotoServer.setMesrecived(null);
						message.setData(bundle);
						message.what = 1;
						draPointHandler.sendMessage(message);
					}
				}
				try {
					Thread.currentThread().sleep(700);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

		}
	});

	@Override
	protected void onCreate(Bundle status) {
		super.onCreate(status);
		setContentView(R.layout.locationmap);
		thread1.start();
		locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
		gpsEnabled = locationManager
				.isProviderEnabled(LocationManager.GPS_PROVIDER);
		seninfotoServer = new ServerContractor();

		LocationListener lclistener = new LocationListener() {
			@Override
			public void onLocationChanged(Location location) {
				double lat = location.getLatitude();
				double lon = location.getLongitude();
				updateMapView(lon, lat);
				sendLocatinToServer(lon, lat);

				System.out.println("γ�ȣ�" + lat + ",����:" + lon);
				GeoPoint gp = new GeoPoint((int) (lat * 1E6), (int) (lon * 1E6));
				//System.out.println(getAddressbyGeoPoint(gp));
				
				tvLng.setText(String.valueOf(lon)) ;
				tvLat.setText(String.valueOf(lat));
			}

			@Override
			public void onProviderDisabled(String provider) {
				System.out.println("onProviderDisabled");

			}

			@Override
			public void onProviderEnabled(String provider) {
				System.out.println("onProviderEnabled");

			}

			@Override
			public void onStatusChanged(String provider, int status,
					Bundle extras) {
				System.out.println("onStatusChanged");
			}
		};
		// locationManager.addGpsStatusListener(LocationMap.this);
		final int t = 1000;
		final int distance = 2;
		System.out.println(gpsEnabled);
		String privider = locationManager.GPS_PROVIDER;
		locationManager.requestLocationUpdates(privider, t, distance,
				lclistener);
		posBitmap = BitmapFactory
				.decodeResource(getResources(), R.drawable.pos);
		fdposBitmap = BitmapFactory
				.decodeResource(getResources(), R.drawable.fdpos);
		// ��ý�����MapView����
		mv = (MapView) findViewById(R.id.mv);
		// ��ȡ�����������ı���
		tvLng = (TextView) findViewById(R.id.lng);
		tvLat = (TextView) findViewById(R.id.lat);
		tvLng.setMaxWidth(130);
		tvLat.setMaxWidth(130);
		tvLng.setMaxLines(1);
		tvLat.setMaxLines(1);
		// ������ʾ�Ŵ���С�Ŀ��ư�ť
		mv.setBuiltInZoomControls(true);
		// ����MapController����
		controller = mv.getController();
		// ���Button����
	
		// ���RadioGroup����
		mapType = (RadioGroup) findViewById(R.id.rg);
		// ΪRadioGroup��ѡ��״̬�ı����Ӽ�����
		mapType.setOnCheckedChangeListener(new OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(RadioGroup group, int checkedId) {
				switch (checkedId) {
				// �����ѡ����"������ͼ"�ĵ�ѡ��
				case R.id.normal:
					mv.setSatellite(false);
					break;
				// �����ѡ����"������ͼ"�ĵ�ѡ��
				case R.id.satellite:
					mv.setSatellite(true);
					break;
				}
			}
		});
	}
	@Override
	protected void onDestroy() {
		super.onDestroy();
		if(seninfotoServer!=null){
		seninfotoServer.disConnect();
		}
	}

	@Override
	protected boolean isRouteDisplayed() {
		return true;
	}

	// ���ݾ��ȡ�γ�Ƚ�MapView��λ��ָ���ص�ķ���
	private void updateMapView(double lng, double lat) {
		// ����γ����Ϣ��װ��GeoPoint����
		GeoPoint gp = new GeoPoint((int) (lat * 1E6), (int) (lng * 1E6));
		// ������ʾ�Ŵ���С��ť
		mv.displayZoomControls(true);
		// ����ͼ�ƶ���ָ���ĵ���λ��
		controller.animateTo(gp);
		// ���MapView��ԭ�е�Overlay����
		List<Overlay> ol = mv.getOverlays();
		// ���ԭ�е�Overlay����

		// ol.clear();
		if (selfPoint != null) {
			ol.remove(selfPoint);
		}
		selfPoint = new PosOverLay(gp, posBitmap);

		// ����һ���µ�OverLay����
		ol.add(selfPoint);
		mv.postInvalidate();
		// GeoPoint gp2 = new GeoPoint((int) (lat * 1E6+5)
		// , (int) (lng * 1E6+5));
		// ol.add(new PosOverLay(gp2, posBitmap));
	}

	public void addMorepoitn(double lon, double lat,String posTag) {
		List<Overlay> ol = mv.getOverlays();
		GeoPoint gp2 = new GeoPoint((int) (lat * 1E6), (int) (lon * 1E6));

		if (friendPoint != null) {
			ol.remove(friendPoint);
		}
		friendPoint = new PosOverLay(gp2, fdposBitmap);
		friendPoint.PosTag = posTag;
		ol.add(friendPoint);
		mv.postInvalidate();
	}
	

	// �ӵ�ַGeopointȡ��Address
	public String getAddressbyGeoPoint(GeoPoint gp) {
		String strReturn = "";
		try {
			/* ����GeoPoint������null */
			if (gp != null) {
				/* ����Geocoder�������ڻ��ָ���ص�ĵ�ַ */
				Geocoder gc = new Geocoder(LocationMap.this,
						Locale.getDefault());

				/* ȡ���������꾭γ�� */
				double geoLatitude = (int) gp.getLatitudeE6() / 1E6;
				double geoLongitude = (int) gp.getLongitudeE6() / 1E6;

				/* �Ծ�γ��ȡ�õ�ַ�������ж��У� */
				List<Address> lstAddress = gc.getFromLocation(geoLatitude,
						geoLongitude, 1);
				StringBuilder sb = new StringBuilder();

				/* �жϵ�ַ�Ƿ�Ϊ���� */
				if (lstAddress.size() > 0) {
					Address adsLocation = lstAddress.get(0);

					for (int i = 0; i < adsLocation.getMaxAddressLineIndex(); i++) {
						sb.append(adsLocation.getAddressLine(i)).append("\n");
					}
					sb.append(adsLocation.getLocality()).append("\n");
					sb.append(adsLocation.getPostalCode()).append("\n");
					sb.append(adsLocation.getCountryName());
				}

				/* ��ȡ�õ��ĵ�ַ��Ϻ�ŵ�stringbuilder����������� */
				strReturn = sb.toString();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return strReturn; 
	}

	private void sendLocatinToServer(double lon, double lat) {
		String mestosend = "" + lon + "," + lat+",lonAndLat";
		seninfotoServer.sendmes(mestosend);
	}

	// @Override
	// public void onGpsStatusChanged(int event) {
	// // TODO Auto-generated method stub
	//
	// }
}