package com.beem.project.beem.LocationService;

import android.app.Activity;

public class FriendsLastLocationActivity extends Activity {
           
}
