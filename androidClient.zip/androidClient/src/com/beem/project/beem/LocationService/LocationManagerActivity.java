package com.beem.project.beem.LocationService;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

import com.beem.project.beem.R;
import com.beem.project.beem.ui.ChangeStatus;
import com.google.android.maps.MapActivity;

public class LocationManagerActivity extends MapActivity  {
	private Button btnfriendsaroud;
	private Button btnfridlast;
	private Button btnbroacast;
	
	@Override
	protected void onCreate(Bundle status)
	{
		super.onCreate(status);
		setContentView(R.layout.location);
		btnfriendsaroud  = (Button) findViewById(R.id.btnfriendsaroud);
		
		btnbroacast = (Button) findViewById(R.id.btnbroacast);
		
		btnfriendsaroud.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				Intent intent=null;
				intent = new Intent(LocationManagerActivity.this,LocationMap.class);
				startActivity(intent);
				LocationManagerActivity.this.finish();
			}
			
		});
	
		
		btnbroacast.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				Intent intent=null;
				intent = new Intent(LocationManagerActivity.this,BroadcastAroudMeActivity.class);
				startActivity(intent);
				LocationManagerActivity.this.finish();
			}
			
		});
	}
	
	@Override
	protected boolean isRouteDisplayed() {
		// TODO Auto-generated method stub
		return false;
	}


}
