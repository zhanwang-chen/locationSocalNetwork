package com.beem.project.beem.LocationService;

import java.util.Iterator;

import org.jivesoftware.smack.Chat;
import org.jivesoftware.smack.Connection;
import org.jivesoftware.smack.MessageListener;
import org.jivesoftware.smack.PacketCollector;
import org.jivesoftware.smack.PacketListener;
import org.jivesoftware.smack.XMPPConnection;
import org.jivesoftware.smack.XMPPException;
import org.jivesoftware.smack.filter.PacketFilter;
import org.jivesoftware.smack.filter.PacketTypeFilter;
import org.jivesoftware.smack.packet.Message;
import org.jivesoftware.smack.packet.Packet;

import android.os.RemoteException;
import android.util.Log;

import com.beem.project.beem.service.ChatAdapter;
import com.beem.project.beem.service.Contact;
import com.beem.project.beem.service.XmppConnectionAdapter;
import com.beem.project.beem.service.XmppFacade;
import com.beem.project.beem.service.aidl.IMessageListener;

public class ServerContractor {
	private static String user = "aa";
	private static String pwd = "aa";
	private String mesTosend;
	private static Chat chat;
	private String mesrecived;
	private static Connection connection;
	private static XmppFacade xmppfacade = XMppfacadeshare.xmppfacade;
	private static XmppConnectionAdapter mConnexion;
	private static ChatAdapter chatAdapter;
 
	 


	public ServerContractor() {
		System.out.println("ServerContractor is running");
		initConnection();
		addpacketProcess();
	}
	
	public static void initConnection() {
		try {
			
		     mConnexion = (XmppConnectionAdapter) xmppfacade.createConnection();
	
            if(null!=xmppfacade){
		       user = xmppfacade.getUserInfo().getJid().split("/")[0];
			    pwd = xmppfacade.getPassd();
           }
//			Iterator<Contact> it = xmppfacade.getRoster().getContactList()
//					.iterator();
//			while (it.hasNext()) {
//				System.out.println(it.next().getJID());
//			}

//			if(mConnexion.disconnect()){
//				Log.i("disocnnet", "sucess");
//			}
//			if(mConnexion.connect()){
//				Log.i("connet", "sucess");
//			}
//			if(mConnexion.login()){
//				Log.i("login", "sucess");
//			}
			
             String host = "10.0.2.2";
             connection = mConnexion.getAdaptee();
            //connection.disconnect();
             
           //  if(mConnexion == null){
              if(true){
            	 host = mConnexion.getAdaptee().getHost();
            	 connection = new XMPPConnection(host);
 				 connection.connect();
 				 
 				  connection.login(user, pwd);
 					 
 			 
 				Log.i("connect", "mConnexion is null ,login sucess");
             }else{
            	 connection = mConnexion.getAdaptee();
            	 Log.i("connect", "mConnexion is not null,use default");
             }
             
             
             
//             10.07 22:14
//             host = mConnexion.getAdaptee().getHost();
//        	 connection = new XMPPConnection(host);
//				connection.connect();
//				connection.login(pwd+user, pwd+pwd);
//				Log.i("logas", pwd+user+"  " +  pwd+pwd);
//				System.out.println("user"+user+"pas"+pwd);
             //
			

//			Message p = new Message();
//			p.setBody("connet test cc");
//			p.setTo("cc@lab-pc");
//			connection.sendPacket(p);
             
		} catch (XMPPException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	//	catch (RemoteException e) {
	//		// TODO Auto-generated catch block
	//		e.printStackTrace();
		//}
		catch (NullPointerException e){
			e.printStackTrace();
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
//		// to try 
//		MessageListener mslistener = 	new MessageListener() {
//
//			public void processMessage(Chat chat, Message message) {
//				Log.i("debug chatAdapter", "Received message from: "+message.getFrom()
//						+ message.getBody());
//				System.out.println("chatAdapter Received message from: "+message.getFrom()
//						+ message.getBody());
//				processReceivedMes(chat, message);
//			}
//
//		};
//		chat = connection.getChatManager().createChat("system@lab-pc",mslistener);
//	 
//		chatAdapter =new ChatAdapter(chat);
////		//

	}

	

	private void addpacketProcess(){
              if(connection==null){
            	  initConnection();
              }
		    //PacketFilter filter = new PacketTypeFilter(Packet.class);
    		PacketFilter filter = new PacketTypeFilter(Packet.class);
    		//org.jivesoftware.smack.filter.
    		 
    		PacketCollector myCollector = connection.createPacketCollector(filter);
    		//PacketCollector myCollector = connection.createPacketCollector(null);
     

    		 
    		PacketListener myListener = new PacketListener() {
    		        public void processPacket(Packet packet) {
    		            System.out.println("recived packet from "+packet.getFrom());
    		            System.out.println("content: "+((Message) packet).getBody());
    		            processReceivedMes(null,(Message) packet);
    		        }
    		    };              
    		 
    		   connection.addPacketListener(myListener, filter);
    		   // connection.addPacketListener(myListener, null);
    		    
     }

	public static void sendmes(String mes) {
		 if(connection==null){
       	  initConnection();
         }
		Message ms = new Message();
		ms.setBody(mes);
		ms.setTo("system@lab-pc");
		connection.sendPacket(ms);
		//mConnexion.getAdaptee().sendPacket(ms);    //15:22
		
//		Message ms = new Message();
//		ms.setBody(mes);
//		ms.setTo("system@lab-pc");
//		connection.sendPacket(ms);
	}

	public static void sendmes(Message mes){
		 if(connection==null){
       	  initConnection();
         }
		mes.setTo("system@lab-pc");
	//	 mConnexion.getAdaptee().sendPacket(mes);
		connection.sendPacket(mes);
		
	}

	private void processReceivedMes(Chat chat, Message message) {
		 
			mesrecived = message.getBody();
		 

	}
	public void disConnect(){
		if(connection!=null){
			connection.disconnect();
		}
		
	}

	public String getMesrecived() {
		return mesrecived;
	}

	public void setMesrecived(String mesrecived) {
		this.mesrecived = mesrecived;
	}
	public String getMesTosend() {
		return mesTosend;
	}

	public void setMesTosend(String mesTosend) {
		this.mesTosend = mesTosend;
	}

}
