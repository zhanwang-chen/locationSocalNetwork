This directory contains the libraries used by BEEM.

The principal one is asmack, a portage of the Smack library for the Android
platform.

The source of the asmack library can be downloaded at
http://dev.beem-project.com/attachments/download/51/asmack-android-2.1-source-beem.zip

See the file doc/asmack-beem/README.txt for more informations.

