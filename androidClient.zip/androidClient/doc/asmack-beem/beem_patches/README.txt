This directory contains different patch to apply on asmack sources. These
patches will allow us to build a custom flavour of asmack for Beem.  This
directory must be copied in the patch directory of asmack in order to be used.
Then build asmack the usual way.

All the patches are released under the Apache License, Version 2.0
You may obtain a copy of the License at
http://www.apache.org.licenses/LICENCE-2.0

